#!/bin/bash
#Mostrar ayuda si pasa el -help como argumento
if [ "$1" == "-help" ] ; then
	echo "Este script genera un archivo .tar.gz con el contenido de los archivos de /var/logs y /www_dir. Usa backup_full.sh <directorio_origen> <directorio_destino>"
	echo "Uso del script: $0 <directorio_origen> <directorio_destino>"
	exit 0
#Validar que pasen 2 argumentos : # en bash es el numero de argumentos pasadosi
elif [ $# -ne 2 ]; then
	echo "Error. Debes usar 2 argumentos. Usa -help para saber cómo debes usarlos"
	exit 1
fi
# Validar que existen los 2 directorios 
if [ ! -d "$1" ]; then
	echo "El directorio de origen no existe"
	   exit 1
elif [ ! -d "$2" ]; then
    echo "Error: El directorio de destino '$2' no existe."
    exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

# Verificar si el backup se creó correctamente
if [ $? -eq 0 ]; then
    echo "Backup creado exitosamente: $2/$BACKUP"
else
    echo "Error: Falló la creación del backup."
    exit 1
fi
